function drawTess(lowt,hight,lowp,highp){
	document.write("<TABLE style=\"border:2px solid #000000; border-collapse:collapse;\">");
	document.write("<tr>");
	key=41;
	hakken13(key,lowt,hight,lowp,highp);
	key=42;
	kokken(key,lowt,hight,lowp,highp);
	key=43;
	hakken12(key,lowt,hight,lowp,highp);
	key=44;
	kokken(key,lowt,hight,lowp,highp);
	key=45;
	hakken12(key,lowt,hight,lowp,highp);
	key=46;
	kokken(key,lowt,hight,lowp,highp);
	key=47;
	hakken13(key,lowt,hight,lowp,highp);
	for(var i=0;i<=2;i++){
		key=i*12+48;
		hakken13(key,lowt,hight,lowp,highp);
		key=i*12+49;
		kokken(key,lowt,hight,lowp,highp);
		key=i*12+50;
		hakken12(key,lowt,hight,lowp,highp);
		key=i*12+51;
		kokken(key,lowt,hight,lowp,highp);
		key=i*12+52;
		hakken13(key,lowt,hight,lowp,highp);
		key=i*12+53;
		hakken13(key,lowt,hight,lowp,highp);
		key=i*12+54;
		kokken(key,lowt,hight,lowp,highp);
		key=i*12+55;
		hakken12(key,lowt,hight,lowp,highp);
		key=i*12+56;
		kokken(key,lowt,hight,lowp,highp);
		key=i*12+57;
		hakken12(key,lowt,hight,lowp,highp);
		key=i*12+58;
		kokken(key,lowt,hight,lowp,highp);
		key=i*12+59;
		hakken13(key,lowt,hight,lowp,highp);

	}
	document.write("</tr><tr>");
	key=41;
	hakken24(key,lowt,hight,lowp,highp);
	key=43;
	hakken24(key,lowt,hight,lowp,highp);
	key=45;
	hakken24(key,lowt,hight,lowp,highp);
	key=47;
	hakken24(key,lowt,hight,lowp,highp);
	for(var i=0;i<=2;i++){
		key=i*12+48;
		hakken25(key,lowt,hight,lowp,highp);
		key=i*12+50;
		hakken24(key,lowt,hight,lowp,highp);
		key=i*12+52;
		hakken24(key,lowt,hight,lowp,highp);
		key=i*12+53;
		hakken24(key,lowt,hight,lowp,highp);
		key=i*12+55;
		hakken24(key,lowt,hight,lowp,highp);
		key=i*12+57;
		hakken24(key,lowt,hight,lowp,highp);
		key=i*12+59;
		hakken24(key,lowt,hight,lowp,highp);
	}
	document.write("</tr>");
	document.write("</table>");
	return;
}
function kokken(key,lowt,hight,lowp,highp){
	if ((key < lowp) || (key > highp)) {
		document.write("<TD colspan=2 bgcolor=#717075>&nbsp;</TD>");
	}
	else if ((key <= highp) && (key > hight)) {//(key<=65)&&(key>77)
		document.write("<TD colspan=2 bgcolor=#742226>&nbsp;</TD>");
	}
	else if ((key >= lowt) && (key <= hight)) {
		document.write("<TD colspan=2 bgcolor=#000000>&nbsp;</TD>");
	}
	else if ((key >= lowp) && (key < lowt)) {
		document.write("<TD colspan=2 bgcolor=#742226>&nbsp;</TD>");
	}

	return;
}
function hakken12(key,lowt,hight,lowp,highp){
	if ((key < lowp) || (key > highp)) {
		document.write("<TD colspan=2 class=\"hakken1g\">&nbsp;</TD>");
	}
	else if ((key >= lowt) && (key <= hight)) {
		document.write("<TD colspan=2 class=\"hakken1\">&nbsp;</TD>");
	}
	else if ((key >= lowp) && (key < lowt)) {
		document.write("<TD colspan=2 class=\"hakken1r\">&nbsp;</TD>");
	}
	else if ((key <= highp) && (key > hight)) {
		document.write("<TD colspan=2 class=\"hakken1r\">&nbsp;</TD>");
	}
	return;
}
function hakken13(key,lowt,hight,lowp,highp){
	if ( (key < lowp) || (key > highp) ) {
		document.write("<TD colspan=3 class=\"hakken1g\">&nbsp;</TD>");
	}
	else if ( (key >= lowt) && (key <= hight) ) {
		document.write("<TD colspan=3 class=\"hakken1\">&nbsp;</TD>");
	}
	else if ( (key >= lowp) && (key < lowt) ) {
		document.write("<TD colspan=3 class=\"hakken1r\">&nbsp;</TD>");
	}
	else if ( (key <= highp) && (key > hight) ) {
		document.write("<TD colspan=3 class=\"hakken1r\">&nbsp;</TD>");
	}
	return;
}
function hakken24(key,lowt,hight,lowp,highp){
	if ( (key < lowp) || (key > highp) ) {
		document.write("<TD colspan=4 class=\"hakken2g\">&nbsp;</TD>");
	}
	else if ( (key >= lowt) && (key <= hight) ) {
		document.write("<TD colspan=4 class=\"hakken2\">&nbsp;</TD>");
	}
	else if ( (key >= lowp) && (key < lowt) ) {
		document.write("<TD colspan=4 class=\"hakken2r\">&nbsp;</TD>");
	}
	else if ( (key <= highp) && (key > hight) ) {
		document.write("<TD colspan=4 class=\"hakken2r\">&nbsp;</TD>");
	}
	return;
}
function hakken25(key,lowt,hight,lowp,highp){
	if ((key < lowp) || (key > highp)) {
		document.write("<TD colspan=4 class=\"hakken2g\">�E</TD>");
	}
	else if ((key >= lowt) && (key <= hight)) {
		document.write("<TD colspan=4 class=\"hakken2\">�E</TD>");
	}
	else if ((key >= lowp) && (key < lowt)) {
		document.write("<TD colspan=4 class=\"hakken2r\">�E</TD>");
	}
	else if ((key <= highp) && (key > hight)) {
		document.write("<TD colspan=4 class=\"hakken2r\">�E</TD>");
	}
	return;
}